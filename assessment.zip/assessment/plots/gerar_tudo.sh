# metrics="gd igd r2 hv"
metrics="igdp hv"
# problems="dtlz1 dtlz2 dtlz3 dtlz4 dtlz5 dtlz6 dtlz7 wfg1 wfg2 wfg3 wfg4 wfg5 wfg6 wfg7 wfg8 wfg9"
problems="dtlz1 dtlz2 dtlz3 dtlz4 wfg1 wfg2 wfg3 wfg4 wfg5 wfg6 wfg7 wfg8 wfg9"

mkdir -p ../../results/img

for problem in $problems; do
	for metric in $metrics; do
		#./boxplot.sh "../../results/up_to_20/all-$problem-$metric.txt"
		#./linhas.sh "../../results/up_to_20/all-$problem-$metric.txt"
		python boxplot.py "../../results/all-$problem-$metric.txt"
		python linhas.py "../../results/all-$problem-$metric.txt"
	done
	#./gdXigd.sh "../../results/all-$problem-gd.txt" "../../results/all-$problem-igd.txt"
done
