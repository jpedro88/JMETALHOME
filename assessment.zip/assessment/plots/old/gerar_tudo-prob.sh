for problem in 1 2 3 4 5 6 7; do
	for obj in 2 3 5 10 15 20; do
		./probabilidades.sh "../../results/novo/novo(0,0)DTLZ$problem-$obj""_probabilities.txt"
	done
done
